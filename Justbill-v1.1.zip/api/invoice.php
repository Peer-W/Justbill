<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

$invoiceId = $_GET['id'] ?? null;

if (!$invoiceId) {
    http_response_code(404);
    echo 'Factuur niet gevonden';
    exit;
}

$invoices = getInvoices();
$invoice = $invoices[$invoiceId] ?? null;

if (!$invoice) {
    http_response_code(404);
    echo 'Factuur niet gevonden';
    exit;
}

// Check access
$isAdmin = isset($_SESSION['admin_id']) || isset($_SESSION['staff_id']);
$isOwner = isset($_SESSION['user_id']) && $_SESSION['user_id'] === $invoice['userId'];

if (!$isAdmin && !$isOwner) {
    http_response_code(403);
    echo 'Geen toegang';
    exit;
}

$settings = getSettings();
$user = getUser($invoice['userId']);
$services = getServices();
$service = $services[$invoice['serviceId']] ?? null;

// Generate HTML invoice
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Factuur <?php echo htmlspecialchars($invoice['id']); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; margin-bottom: 40px; }
        .logo { font-size: 24px; font-weight: bold; color: #3b82f6; }
        .invoice-info { text-align: right; }
        .invoice-title { font-size: 32px; color: #1f2937; margin-bottom: 5px; }
        .invoice-number { color: #6b7280; }
        .parties { display: flex; justify-content: space-between; margin-bottom: 40px; }
        .party { width: 45%; }
        .party-title { font-weight: bold; color: #6b7280; margin-bottom: 10px; text-transform: uppercase; font-size: 12px; }
        .party-name { font-size: 18px; font-weight: bold; margin-bottom: 5px; }
        .party-detail { color: #6b7280; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        th { background: #f3f4f6; padding: 12px; text-align: left; font-size: 12px; text-transform: uppercase; color: #6b7280; }
        td { padding: 12px; border-bottom: 1px solid #e5e7eb; }
        .total-row td { font-weight: bold; font-size: 18px; border-top: 2px solid #1f2937; }
        .status { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .status-paid { background: #d1fae5; color: #065f46; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center; color: #6b7280; font-size: 12px; }
        @media print { body { padding: 20px; } .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #3b82f6; color: white; border: none; border-radius: 5px; cursor: pointer;">Print / Download PDF</button>
        <a href="/client?page=invoices" style="margin-left: 10px; color: #3b82f6;">Terug naar facturen</a>
    </div>
    
    <div class="header">
        <div class="logo"><?php echo htmlspecialchars($settings['siteName']); ?></div>
        <div class="invoice-info">
            <div class="invoice-title">FACTUUR</div>
            <div class="invoice-number">#<?php echo htmlspecialchars($invoice['id']); ?></div>
        </div>
    </div>
    
    <div class="parties">
        <div class="party">
            <div class="party-title">Van</div>
            <div class="party-name"><?php echo htmlspecialchars($settings['siteName']); ?></div>
            <div class="party-detail"><?php echo htmlspecialchars($settings['companyEmail'] ?? ''); ?></div>
            <div class="party-detail"><?php echo htmlspecialchars($settings['companyAddress'] ?? ''); ?></div>
            <div class="party-detail">KVK: <?php echo htmlspecialchars($settings['kvkNumber'] ?? ''); ?></div>
            <div class="party-detail">BTW: <?php echo htmlspecialchars($settings['vatNumber'] ?? ''); ?></div>
        </div>
        <div class="party">
            <div class="party-title">Aan</div>
            <div class="party-name"><?php echo htmlspecialchars($user['name'] ?? 'Onbekend'); ?></div>
            <div class="party-detail"><?php echo htmlspecialchars($user['email'] ?? ''); ?></div>
            <div class="party-detail"><?php echo htmlspecialchars($user['address'] ?? ''); ?></div>
            <div class="party-detail"><?php echo htmlspecialchars($user['city'] ?? ''); ?></div>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Omschrijving</th>
                <th>Periode</th>
                <th style="text-align: right;">Bedrag</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo htmlspecialchars($service['productName'] ?? 'Dienst'); ?></td>
                <td><?php echo date('d-m-Y', strtotime($invoice['created'])); ?></td>
                <td style="text-align: right;">&euro; <?php echo number_format($invoice['amount'], 2, ',', '.'); ?></td>
            </tr>
            <tr class="total-row">
                <td colspan="2">Totaal</td>
                <td style="text-align: right;">&euro; <?php echo number_format($invoice['amount'], 2, ',', '.'); ?></td>
            </tr>
        </tbody>
    </table>
    
    <div>
        <strong>Status:</strong> 
        <span class="status <?php echo $invoice['status'] === 'paid' ? 'status-paid' : 'status-pending'; ?>">
            <?php echo $invoice['status'] === 'paid' ? 'Betaald' : 'Openstaand'; ?>
        </span>
        <?php if ($invoice['paidAt']): ?>
        <span style="margin-left: 10px; color: #6b7280;">
            Betaald op <?php echo date('d-m-Y H:i', strtotime($invoice['paidAt'])); ?>
        </span>
        <?php endif; ?>
    </div>
    
    <div class="footer">
        <p>Bedankt voor uw vertrouwen in <?php echo htmlspecialchars($settings['siteName']); ?></p>
        <p><?php echo htmlspecialchars($settings['siteUrl'] ?? ''); ?></p>
    </div>
</body>
</html>
