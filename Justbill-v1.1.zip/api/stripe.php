<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

$settings = getSettings();
$stripeSecretKey = $settings['stripeSecretKey'] ?? '';

if (empty($stripeSecretKey)) {
    echo json_encode(['error' => 'Stripe is niet geconfigureerd']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? $action;
}

function stripeRequest($endpoint, $method = 'GET', $data = null) {
    global $stripeSecretKey;
    
    $ch = curl_init("https://api.stripe.com/v1/$endpoint");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $stripeSecretKey . ':');
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }
    }
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

switch ($action) {
    case 'create_checkout':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Niet ingelogd']);
            exit;
        }
        
        $productId = $input['productId'] ?? null;
        $products = getProducts();
        
        if (!$productId || !isset($products[$productId])) {
            echo json_encode(['error' => 'Product niet gevonden']);
            exit;
        }
        
        $product = $products[$productId];
        $user = getUser($_SESSION['user_id']);
        
        if (empty($product['stripePriceId'])) {
            echo json_encode(['error' => 'Product heeft geen Stripe prijs']);
            exit;
        }
        
        $checkoutData = [
            'mode' => $product['billingType'] === 'subscription' ? 'subscription' : 'payment',
            'success_url' => $settings['siteUrl'] . '/client?page=services&success=1',
            'cancel_url' => $settings['siteUrl'] . '/client?page=services&cancelled=1',
            'customer_email' => $user['email'],
            'line_items[0][price]' => $product['stripePriceId'],
            'line_items[0][quantity]' => 1,
            'metadata[user_id]' => $_SESSION['user_id'],
            'metadata[product_id]' => $productId
        ];
        
        $session = stripeRequest('checkout/sessions', 'POST', $checkoutData);
        
        if (isset($session['error'])) {
            echo json_encode(['error' => $session['error']['message'] ?? 'Stripe fout']);
            exit;
        }
        
        echo json_encode(['url' => $session['url']]);
        break;
        
    case 'webhook':
        $payload = file_get_contents('php://input');
        $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
        $webhookSecret = $settings['stripeWebhookSecret'] ?? '';
        
        // Simple signature verification (in production use proper verification)
        $event = json_decode($payload, true);
        
        if (!$event) {
            http_response_code(400);
            exit;
        }
        
        switch ($event['type']) {
            case 'checkout.session.completed':
                $session = $event['data']['object'];
                $userId = $session['metadata']['user_id'] ?? null;
                $productId = $session['metadata']['product_id'] ?? null;
                
                if ($userId && $productId) {
                    // Create service for user
                    $services = getServices();
                    $serviceId = uniqid('svc_');
                    $products = getProducts();
                    $product = $products[$productId] ?? null;
                    
                    $services[$serviceId] = [
                        'id' => $serviceId,
                        'userId' => $userId,
                        'productId' => $productId,
                        'productName' => $product['name'] ?? 'Unknown',
                        'status' => 'active',
                        'created' => date('Y-m-d H:i:s'),
                        'nextBilling' => $product['billingType'] === 'subscription' 
                            ? date('Y-m-d', strtotime('+1 month'))
                            : null,
                        'stripeSubscriptionId' => $session['subscription'] ?? null,
                        'stripeCustomerId' => $session['customer'] ?? null
                    ];
                    saveServices($services);
                    
                    // Create invoice
                    $invoices = getInvoices();
                    $invoiceId = uniqid('inv_');
                    $invoices[$invoiceId] = [
                        'id' => $invoiceId,
                        'userId' => $userId,
                        'serviceId' => $serviceId,
                        'amount' => $session['amount_total'] / 100,
                        'currency' => $session['currency'],
                        'status' => 'paid',
                        'created' => date('Y-m-d H:i:s'),
                        'paidAt' => date('Y-m-d H:i:s'),
                        'stripePaymentId' => $session['payment_intent'] ?? $session['id']
                    ];
                    saveInvoices($invoices);
                    
                    // Log
                    addLog('payment', "Payment received for user $userId, product $productId");
                }
                break;
                
            case 'customer.subscription.deleted':
                $subscription = $event['data']['object'];
                $services = getServices();
                
                foreach ($services as $id => &$service) {
                    if ($service['stripeSubscriptionId'] === $subscription['id']) {
                        $service['status'] = 'cancelled';
                        $service['cancelledAt'] = date('Y-m-d H:i:s');
                        break;
                    }
                }
                saveServices($services);
                break;
        }
        
        echo json_encode(['received' => true]);
        break;
        
    case 'cancel_subscription':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Niet ingelogd']);
            exit;
        }
        
        $serviceId = $input['serviceId'] ?? null;
        $services = getServices();
        
        if (!$serviceId || !isset($services[$serviceId])) {
            echo json_encode(['error' => 'Service niet gevonden']);
            exit;
        }
        
        $service = $services[$serviceId];
        
        if ($service['userId'] !== $_SESSION['user_id']) {
            echo json_encode(['error' => 'Geen toegang']);
            exit;
        }
        
        if ($service['stripeSubscriptionId']) {
            stripeRequest("subscriptions/{$service['stripeSubscriptionId']}", 'POST', [
                'cancel_at_period_end' => 'true'
            ]);
        }
        
        $services[$serviceId]['status'] = 'cancelling';
        $services[$serviceId]['cancelRequestedAt'] = date('Y-m-d H:i:s');
        saveServices($services);
        
        echo json_encode(['success' => true]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
