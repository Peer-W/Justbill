import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Admin | JustBill",
  description: "JustBill administration portal",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
