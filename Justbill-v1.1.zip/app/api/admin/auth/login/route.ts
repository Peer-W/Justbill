import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { getAdminCredentials } from "@/lib/data-store"

export async function POST(request: Request) {
  const { username, password } = await request.json()
  const credentials = await getAdminCredentials()

  if (username === credentials.username && password === credentials.password) {
    const cookieStore = await cookies()
    cookieStore.set("admin_session", "authenticated", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24, // 24 hours
    })

    return NextResponse.json({ success: true })
  }

  return NextResponse.json({ error: "Ongeldige inloggegevens" }, { status: 401 })
}
