import { NextResponse } from "next/server"
import { getAdminCredentials, updateAdminCredentials } from "@/lib/data-store"

export async function PUT(request: Request) {
  const { currentPassword, newUsername, newPassword } = await request.json()
  const credentials = await getAdminCredentials()

  if (currentPassword !== credentials.password) {
    return NextResponse.json({ error: "Huidig wachtwoord is onjuist" }, { status: 401 })
  }

  const updatedCredentials = await updateAdminCredentials({
    username: newUsername || credentials.username,
    password: newPassword || credentials.password,
  })

  return NextResponse.json({ success: true, username: updatedCredentials.username })
}
