import { NextResponse } from "next/server"
import { updateProduct, deleteProduct } from "@/lib/data-store"

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const product = await request.json()
  const updatedProduct = await updateProduct(id, product)
  return NextResponse.json(updatedProduct)
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  await deleteProduct(id)
  return NextResponse.json({ success: true })
}
