import { NextResponse } from "next/server"
import { getProducts, addProduct } from "@/lib/data-store"

export async function GET() {
  const products = await getProducts()
  return NextResponse.json(products)
}

export async function POST(request: Request) {
  const product = await request.json()
  const newProduct = await addProduct(product)
  return NextResponse.json(newProduct)
}
