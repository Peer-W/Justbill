import { NextResponse } from "next/server"
import { getSettings, updateSettings } from "@/lib/data-store"

export async function GET() {
  const settings = await getSettings()
  return NextResponse.json(settings)
}

export async function PUT(request: Request) {
  const settings = await request.json()
  const updatedSettings = await updateSettings(settings)
  return NextResponse.json(updatedSettings)
}
