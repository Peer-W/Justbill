"use client"

import { useState } from "react"
import { BarChart3, CreditCard, FileText, Headphones, LayoutDashboard, LogOut, Plus, Server, Settings, Ticket, Globe, Code2 } from "lucide-react"

const services = [
  { name: "Pro Webhosting", status: "Active", domain: "example.nl", renewal: "12 Oct 2026", icon: Globe },
  { name: "VPS Starter", status: "Active", domain: "vps-104.justbill.xyz", renewal: "03 Nov 2026", icon: Server },
]

const invoices = [
  { id: "INV-2026-0041", date: "12 Sep 2026", amount: "€12.50", status: "Paid" },
  { id: "INV-2026-0038", date: "12 Aug 2026", amount: "€12.50", status: "Paid" },
  { id: "INV-2026-0035", date: "12 Jul 2026", amount: "€8.00", status: "Paid" },
]

export default function ClientPortalPage() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [active, setActive] = useState("Overview")
  const [ticketSent, setTicketSent] = useState(false)

  if (!loggedIn) {
    return <LoginScreen onLogin={() => setLoggedIn(true)} />
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-border bg-card lg:block">
        <div className="flex h-full flex-col p-5">
          <div className="flex items-center gap-3 border-b border-border pb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-lg font-bold text-primary-foreground">P</div>
            <div><p className="font-semibold">JustBill</p><p className="text-xs text-muted-foreground">Customer portal</p></div>
          </div>
          <nav className="mt-8 flex-1 space-y-1">
            {[["Overview", LayoutDashboard], ["Services", Server], ["Invoices", CreditCard], ["Support tickets", Ticket], ["Account settings", Settings]].map(([label, Icon]) => (
              <button key={label as string} onClick={() => setActive(label as string)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${active === label ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}><Icon className="h-4 w-4" />{label as string}</button>
            ))}
          </nav>
          <button onClick={() => setLoggedIn(false)} className="flex items-center gap-3 border-t border-border pt-5 text-sm text-muted-foreground hover:text-foreground"><LogOut className="h-4 w-4" />Sign out</button>
        </div>
      </aside>
      <main className="lg:pl-64">
        <header className="flex items-center justify-between border-b border-border px-6 py-5 md:px-10"><div><p className="text-sm text-muted-foreground">Monday, 14 September 2026</p><h1 className="mt-1 text-2xl font-semibold tracking-tight">{active}</h1></div><div className="flex items-center gap-3"><div className="hidden text-right sm:block"><p className="text-sm font-medium">Alex Johnson</p><p className="text-xs text-muted-foreground">alex@example.com</p></div><div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary font-semibold text-secondary-foreground">AJ</div></div></header>
        <div className="p-6 md:p-10">
          {active === "Overview" && <Overview onOpenTicket={() => setActive("Support tickets")} />}
          {active === "Services" && <ServicesView />}
          {active === "Invoices" && <InvoicesView />}
          {active === "Support tickets" && <TicketsView sent={ticketSent} onSent={() => setTicketSent(true)} />}
          {active === "Account settings" && <SettingsView />}
        </div>
      </main>
      <a href="https://justbill.xyz" target="_blank" rel="noopener noreferrer" className="fixed bottom-4 right-4 z-50 rounded-md border border-border bg-card/95 px-3 py-2 text-xs text-muted-foreground shadow-lg backdrop-blur hover:text-foreground">Powered by JustBill</a>
    </div>
  )
}

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  return <main className="flex min-h-screen items-center justify-center bg-background p-6"><div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-2xl"><div className="mb-8 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-xl font-bold text-primary-foreground">P</div><div><p className="font-semibold">JustBill</p><p className="text-sm text-muted-foreground">Customer portal</p></div></div><h1 className="text-2xl font-semibold">Welcome back</h1><p className="mt-2 text-sm leading-6 text-muted-foreground">Sign in to manage your services, invoices, and support requests.</p><form onSubmit={(event) => { event.preventDefault(); onLogin() }} className="mt-8 space-y-4"><label className="block text-sm"><span className="mb-2 block">Email address</span><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary" type="email" placeholder="you@example.com" required /></label><label className="block text-sm"><span className="mb-2 block">Password</span><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary" type="password" placeholder="Your password" required /></label><button className="w-full rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground hover:opacity-90">Sign in</button></form><p className="mt-6 text-center text-sm text-muted-foreground">Need an account? <button className="text-primary hover:underline">Create one</button></p></div></main>
}

function Overview({ onOpenTicket }: { onOpenTicket: () => void }) {
  return <div className="space-y-8"><section className="grid gap-4 md:grid-cols-3"><Metric icon={Server} label="Active services" value="2" /><Metric icon={CreditCard} label="Next payment" value="€12.50" detail="12 Oct 2026" /><Metric icon={Ticket} label="Open tickets" value="1" detail="Awaiting reply" /></section><section className="grid gap-6 xl:grid-cols-[1.4fr_1fr]"><div className="rounded-xl border border-border bg-card p-6"><div className="flex items-center justify-between"><div><h2 className="font-semibold">Your services</h2><p className="mt-1 text-sm text-muted-foreground">Services currently linked to your account.</p></div><button className="text-sm text-primary hover:underline">View all</button></div><div className="mt-6 space-y-3">{services.map((service) => <ServiceRow key={service.name} {...service} />)}</div></div><div className="rounded-xl border border-border bg-card p-6"><div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary"><Code2 className="h-5 w-5" /></div><h2 className="mt-5 font-semibold">Need something custom?</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Tell us about your website or Node.js application. Our development team will follow up with a plan and estimate.</p><button onClick={onOpenTicket} className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground"><Plus className="h-4 w-4" />Open a project request</button></div></section><section className="rounded-xl border border-border bg-card p-6"><h2 className="font-semibold">Recent invoices</h2><div className="mt-5 divide-y divide-border">{invoices.slice(0, 2).map((invoice) => <div key={invoice.id} className="flex items-center justify-between py-4 first:pt-0"><div><p className="text-sm font-medium">{invoice.id}</p><p className="mt-1 text-xs text-muted-foreground">{invoice.date}</p></div><div className="flex items-center gap-5"><span className="text-sm font-medium">{invoice.amount}</span><span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs text-emerald-400">{invoice.status}</span><FileText className="h-4 w-4 text-muted-foreground" /></div></div>)}</div></section></div>
}

function Metric({ icon: Icon, label, value, detail }: { icon: typeof Server; label: string; value: string; detail?: string }) { return <div className="rounded-xl border border-border bg-card p-5"><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">{label}</span><Icon className="h-4 w-4 text-primary" /></div><p className="mt-4 text-2xl font-semibold">{value}</p>{detail && <p className="mt-1 text-xs text-muted-foreground">{detail}</p>}</div> }

function ServiceRow({ name, status, domain, renewal, icon: Icon }: typeof services[number]) { return <div className="flex items-center justify-between rounded-lg border border-border p-4"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted"><Icon className="h-4 w-4 text-primary" /></div><div><p className="text-sm font-medium">{name}</p><p className="mt-1 text-xs text-muted-foreground">{domain}</p></div></div><div className="text-right"><span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs text-emerald-400">{status}</span><p className="mt-2 text-xs text-muted-foreground">Renews {renewal}</p></div></div> }

function ServicesView() { return <div className="space-y-5">{services.map((service) => <ServiceRow key={service.name} {...service} />)}<button className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm hover:bg-muted"><Plus className="h-4 w-4" />Order another service</button></div> }
function InvoicesView() { return <div className="rounded-xl border border-border bg-card"><div className="border-b border-border p-6"><h2 className="font-semibold">Invoices</h2><p className="mt-1 text-sm text-muted-foreground">Your complete payment history.</p></div><div className="divide-y divide-border">{invoices.map((invoice) => <div key={invoice.id} className="flex items-center justify-between p-5"><div><p className="text-sm font-medium">{invoice.id}</p><p className="mt-1 text-xs text-muted-foreground">Issued {invoice.date}</p></div><div className="flex items-center gap-5"><span className="text-sm font-medium">{invoice.amount}</span><span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs text-emerald-400">{invoice.status}</span><button className="text-sm text-primary hover:underline">Download</button></div></div>)}</div></div> }
function TicketsView({ sent, onSent }: { sent: boolean; onSent: () => void }) { return <div className="grid gap-6 xl:grid-cols-[1fr_1.2fr]"><div className="rounded-xl border border-border bg-card p-6"><h2 className="font-semibold">Open a support ticket</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Need a custom website or Node.js program? Send us the details and our team will reply during business hours.</p>{sent ? <div className="mt-6 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-sm text-emerald-300">Your request has been received. We will follow up within 24 working hours.</div> : <form onSubmit={(event) => { event.preventDefault(); onSent() }} className="mt-6 space-y-4"><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm" placeholder="Subject" required /><select className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm"><option>Custom website</option><option>Node.js program</option><option>Existing service support</option></select><textarea className="min-h-32 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm" placeholder="Describe your project or question..." required /><button className="rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground">Submit ticket</button></form>}</div><div className="rounded-xl border border-border bg-card p-6"><h2 className="font-semibold">Your tickets</h2><div className="mt-5 rounded-lg border border-border p-4"><div className="flex justify-between"><p className="text-sm font-medium">DNS record update</p><span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-xs text-amber-300">Open</span></div><p className="mt-2 text-xs text-muted-foreground">Last updated 14 Sep 2026</p></div></div></div> }
function SettingsView() { return <div className="max-w-2xl rounded-xl border border-border bg-card p-6"><h2 className="font-semibold">Account settings</h2><div className="mt-6 grid gap-4 sm:grid-cols-2"><label className="text-sm"><span className="mb-2 block">First name</span><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5" defaultValue="Alex" /></label><label className="text-sm"><span className="mb-2 block">Last name</span><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5" defaultValue="Johnson" /></label><label className="text-sm sm:col-span-2"><span className="mb-2 block">Email address</span><input className="w-full rounded-lg border border-input bg-background px-3 py-2.5" defaultValue="alex@example.com" type="email" /></label></div><button className="mt-6 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground">Save changes</button></div> }
