import Link from "next/link"

export default function InstallPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-12 text-foreground">
      <div className="mx-auto max-w-3xl">
        <div className="mb-10 flex items-center justify-between">
          <div>
            <p className="font-mono text-sm uppercase tracking-[0.2em] text-primary">JustBill</p>
            <h1 className="mt-3 text-4xl font-semibold tracking-tight">Initial setup</h1>
            <p className="mt-3 max-w-xl text-muted-foreground leading-6">
              Configure your brand, language, administrator account, and private admin URL before launching the platform.
            </p>
          </div>
          <span className="rounded-full border border-border px-3 py-1 font-mono text-xs text-muted-foreground">Step 1 of 1</span>
        </div>

        <form className="space-y-8 rounded-2xl border border-border bg-card p-6 shadow-2xl md:p-8">
          <section className="space-y-5">
            <div>
              <h2 className="text-xl font-medium">Branding</h2>
              <p className="mt-1 text-sm text-muted-foreground">These settings will be used throughout the customer portal.</p>
            </div>
            <div className="grid gap-5 md:grid-cols-2">
              <label className="space-y-2 text-sm">
                <span>Platform name</span>
                <input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none ring-primary focus:ring-2" defaultValue="JustBill" name="site_name" required />
              </label>
              <label className="space-y-2 text-sm">
                <span>Logo</span>
                <input className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-2 file:text-primary-foreground" name="logo" type="file" accept="image/png,image/jpeg,image/svg+xml" />
              </label>
            </div>
            <label className="space-y-2 text-sm">
              <span>Custom CSS <span className="text-muted-foreground">(optional)</span></span>
              <textarea className="min-h-32 w-full rounded-lg border border-input bg-background px-3 py-2.5 font-mono text-sm outline-none ring-primary focus:ring-2" name="custom_css" placeholder="Add your own CSS rules here..." />
            </label>
          </section>

          <section className="space-y-5 border-t border-border pt-8">
            <div>
              <h2 className="text-xl font-medium">Language</h2>
              <p className="mt-1 text-sm text-muted-foreground">Automatic mode uses Dutch for Belgian visitors and English elsewhere.</p>
            </div>
            <select className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none ring-primary focus:ring-2" defaultValue="auto" name="language_mode">
              <option value="auto">Automatic</option>
              <option value="nl">Nederlands</option>
              <option value="en">English</option>
            </select>
          </section>

          <section className="space-y-5 border-t border-border pt-8">
            <div>
              <h2 className="text-xl font-medium">Administrator</h2>
              <p className="mt-1 text-sm text-muted-foreground">Choose a private URL for the control panel.</p>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              <label className="space-y-2 text-sm md:col-span-1">
                <span>Admin URL</span>
                <div className="flex items-center rounded-lg border border-input bg-background px-3 focus-within:ring-2 focus-within:ring-primary">
                  <span className="text-muted-foreground">/</span>
                  <input className="min-w-0 flex-1 bg-transparent px-1 py-2.5 outline-none" defaultValue="admin" name="admin_path" pattern="[a-zA-Z0-9_-]+" required />
                </div>
              </label>
              <label className="space-y-2 text-sm md:col-span-1">
                <span>Username</span>
                <input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none ring-primary focus:ring-2" name="username" required />
              </label>
              <label className="space-y-2 text-sm md:col-span-1">
                <span>Password</span>
                <input className="w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none ring-primary focus:ring-2" name="password" type="password" required />
              </label>
            </div>
            <p className="rounded-lg border border-primary/30 bg-primary/10 p-3 text-sm text-muted-foreground">
              Remember your admin URL. After installation, the default admin path will not be exposed.
            </p>
          </section>

          <div className="flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
            <Link className="text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline" href="/">Back to homepage</Link>
            <button className="rounded-lg bg-primary px-5 py-2.5 font-medium text-primary-foreground transition-opacity hover:opacity-90" type="submit">Install JustBill</button>
          </div>
          </form>
        <a href="https://justbill.xyz" target="_blank" rel="noopener noreferrer" className="mt-6 block text-center text-xs text-muted-foreground hover:text-foreground">Powered by JustBill</a>
      </div>
    </main>
  )
}
