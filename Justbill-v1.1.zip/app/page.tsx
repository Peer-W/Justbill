import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Services } from "@/components/services"
import { InfoSection } from "@/components/info-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Services />
        <InfoSection />
      </main>
      <Footer />
      <a href="https://justbill.xyz" target="_blank" rel="noopener noreferrer" className="fixed bottom-4 right-4 z-50 rounded-md border border-border bg-card/95 px-3 py-2 text-xs text-muted-foreground shadow-lg backdrop-blur hover:text-foreground">Powered by JustBill</a>
    </div>
  )
}
