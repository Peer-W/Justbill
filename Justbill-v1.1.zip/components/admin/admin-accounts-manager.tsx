"use client"

import { useState } from "react"
import { Plus, ShieldCheck, UserRound, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface AdminAccount { id: string; name: string; email: string; role: string; active: boolean }

const initialAccounts: AdminAccount[] = [
  { id: "1", name: "Primary administrator", email: "owner@justbill.xyz", role: "Owner", active: true },
]

export function AdminAccountsManager() {
  const [accounts, setAccounts] = useState(initialAccounts)
  const [form, setForm] = useState({ name: "", email: "", role: "Support" })
  const [showForm, setShowForm] = useState(false)

  const addAccount = (event: React.FormEvent) => {
    event.preventDefault()
    if (!form.name || !form.email) return
    setAccounts((current) => [...current, { id: crypto.randomUUID(), ...form, active: true }])
    setForm({ name: "", email: "", role: "Support" })
    setShowForm(false)
  }

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Admin accounts</h2><p className="text-sm text-muted-foreground">Manage separate administrator access for your team.</p></div>
        <Button onClick={() => setShowForm((value) => !value)} className="gap-2"><Plus className="h-4 w-4" />Add account</Button>
      </div>
      {showForm && <Card><CardHeader><CardTitle>New admin account</CardTitle><CardDescription>The account owner will receive an invitation to set a password.</CardDescription></CardHeader><CardContent><form onSubmit={addAccount} className="grid gap-4 sm:grid-cols-3"><Input placeholder="Full name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required /><Input type="email" placeholder="Email address" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} required /><select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.role} onChange={(event) => setForm({ ...form, role: event.target.value })}><option>Support</option><option>Billing</option><option>Editor</option><option>Administrator</option></select><Button type="submit" className="sm:col-span-3">Create account</Button></form></CardContent></Card>}
      <div className="grid gap-3">{accounts.map((account) => <Card key={account.id}><CardContent className="flex flex-wrap items-center justify-between gap-4 p-5"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary"><UserRound className="h-5 w-5" /></div><div><p className="font-medium">{account.name}</p><p className="text-sm text-muted-foreground">{account.email}</p></div></div><div className="flex items-center gap-2"><Badge variant="secondary"><ShieldCheck className="mr-1 h-3 w-3" />{account.role}</Badge><Badge variant={account.active ? "default" : "outline"}>{account.active ? "Active" : "Disabled"}</Badge>{account.role !== "Owner" && <Button variant="ghost" size="icon" onClick={() => setAccounts((current) => current.filter((item) => item.id !== account.id))} aria-label={`Delete ${account.name}`}><Trash2 className="h-4 w-4" /></Button>}</div></CardContent></Card>)}</div>
    </div>
  )
}
