"use client"

import { useState } from "react"
import Image from "next/image"
import { LogOut, Package, Settings, Key, UsersRound, Palette, Receipt, Ticket, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ProductManager } from "@/components/admin/product-manager"
import { SettingsManager } from "@/components/admin/settings-manager"
import { PasswordManager } from "@/components/admin/password-manager"
import { AdminAccountsManager } from "@/components/admin/admin-accounts-manager"
import { WhiteLabelManager } from "@/components/admin/white-label-manager"

interface AdminDashboardProps {
  onLogout: () => void
}

function CustomerOverview() {
  const customers = [{ name: "Avery Johnson", email: "avery@example.com", services: 3, status: "Active" }, { name: "Sofia de Vries", email: "sofia@example.com", services: 1, status: "Active" }, { name: "Noah Peters", email: "noah@example.com", services: 0, status: "Pending" }]
  return <div className="max-w-4xl space-y-6"><div><h2 className="text-2xl font-bold">Customers</h2><p className="text-sm text-muted-foreground">Manage accounts, services, renewals, and password resets.</p></div><div className="grid gap-3">{customers.map((customer) => <Card key={customer.email}><CardContent className="flex flex-wrap items-center justify-between gap-4 p-5"><div><p className="font-medium">{customer.name}</p><p className="text-sm text-muted-foreground">{customer.email}</p></div><div className="flex items-center gap-2 text-sm text-muted-foreground"><span>{customer.services} services</span><span className="rounded-full bg-primary/10 px-2 py-1 text-primary">{customer.status}</span><Button variant="outline" size="sm">Manage</Button></div></CardContent></Card>)}</div></div>
}

function BillingOverview() {
  return <div className="max-w-4xl space-y-6"><div><h2 className="text-2xl font-bold">Billing & checkout</h2><p className="text-sm text-muted-foreground">Control payments, invoices, coupons, and checkout behavior.</p></div><div className="grid gap-4 sm:grid-cols-3"><Card><CardHeader><CardTitle>Stripe</CardTitle><CardDescription>Online payments</CardDescription></CardHeader><CardContent><Badge variant="secondary">Disabled</Badge></CardContent></Card><Card><CardHeader><CardTitle>Manual invoices</CardTitle><CardDescription>Bank transfer checkout</CardDescription></CardHeader><CardContent><Badge>Enabled</Badge></CardContent></Card><Card><CardHeader><CardTitle>Coupons</CardTitle><CardDescription>Active discount codes</CardDescription></CardHeader><CardContent><Button variant="outline" size="sm">Manage coupons</Button></CardContent></Card></div></div>
}

type Tab = "products" | "settings" | "password" | "customers" | "billing" | "branding" | "team"

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<Tab>("products")

  const tabs = [
    { id: "products" as Tab, label: "Products", icon: Package },
    { id: "settings" as Tab, label: "Instellingen", icon: Settings },
    { id: "password" as Tab, label: "Password", icon: Key },
    { id: "customers" as Tab, label: "Customers", icon: UsersRound },
    { id: "billing" as Tab, label: "Billing & checkout", icon: Receipt },
    { id: "branding" as Tab, label: "White-label", icon: Palette },
    { id: "team" as Tab, label: "Admin accounts", icon: ShieldCheck },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4">
            <Image
              src="/logo.png"
              alt="PW-Services Logo"
              width={120}
              height={32}
              className="h-8 w-auto"
            />
            <span className="rounded-md bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
              Admin
            </span>
          </div>
          <Button variant="outline" size="sm" onClick={onLogout} className="gap-2">
            <LogOut className="h-4 w-4" />
            Uitloggen
          </Button>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Tabs */}
        <div className="mb-8 flex gap-2 overflow-x-auto border-b border-border pb-4">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab(tab.id)}
              className="gap-2"
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Content */}
        {activeTab === "products" && <ProductManager />}
        {activeTab === "settings" && <SettingsManager />}
        {activeTab === "password" && <PasswordManager />}
        {activeTab === "customers" && <CustomerOverview />}
        {activeTab === "billing" && <BillingOverview />}
        {activeTab === "branding" && <WhiteLabelManager />}
        {activeTab === "team" && <AdminAccountsManager />}
      </div>
    </div>
  )
}
