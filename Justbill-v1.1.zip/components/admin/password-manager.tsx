"use client"

import { useState } from "react"
import { Save, AlertCircle, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"

export function PasswordManager() {
  const [currentPassword, setCurrentPassword] = useState("")
  const [newUsername, setNewUsername] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setError("")
    setSuccess("")

    if (newPassword !== confirmPassword) {
      setError("Wachtwoorden komen niet overeen")
      return
    }

    if (newPassword && newPassword.length < 4) {
      setError("Wachtwoord moet minimaal 4 tekens zijn")
      return
    }

    setIsSaving(true)

    try {
      const res = await fetch("/api/admin/auth/update", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newUsername: newUsername || undefined,
          newPassword: newPassword || undefined,
        }),
      })

      const data = await res.json()

      if (res.ok) {
        setSuccess("Inloggegevens bijgewerkt")
        setCurrentPassword("")
        setNewUsername("")
        setNewPassword("")
        setConfirmPassword("")
      } else {
        setError(data.error || "Er is een fout opgetreden")
      }
    } catch {
      setError("Er is een fout opgetreden")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">Wachtwoord wijzigen</h2>
        <p className="text-sm text-muted-foreground">Wijzig je admin inloggegevens</p>
      </div>

      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-foreground">Inloggegevens</CardTitle>
          <CardDescription>
            Vul je huidige wachtwoord in en stel nieuwe inloggegevens in
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <Field>
              <FieldLabel>Huidig wachtwoord *</FieldLabel>
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Voer huidig wachtwoord in"
              />
            </Field>

            <div className="border-t border-border pt-4">
              <p className="mb-4 text-sm text-muted-foreground">
                Laat velden leeg om ze niet te wijzigen
              </p>
            </div>

            <Field>
              <FieldLabel>Nieuwe gebruikersnaam</FieldLabel>
              <Input
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Nieuwe gebruikersnaam"
              />
            </Field>

            <Field>
              <FieldLabel>Nieuw wachtwoord</FieldLabel>
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Nieuw wachtwoord"
              />
            </Field>

            <Field>
              <FieldLabel>Bevestig nieuw wachtwoord</FieldLabel>
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Bevestig nieuw wachtwoord"
              />
            </Field>

            {error && (
              <div className="flex items-center gap-2 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 rounded-md bg-green-500/10 px-3 py-2 text-sm text-green-500">
                <CheckCircle className="h-4 w-4" />
                {success}
              </div>
            )}

            <Button onClick={handleSave} disabled={isSaving || !currentPassword} className="gap-2">
              <Save className="h-4 w-4" />
              {isSaving ? "Opslaan..." : "Opslaan"}
            </Button>
          </FieldGroup>
        </CardContent>
      </Card>
    </div>
  )
}
