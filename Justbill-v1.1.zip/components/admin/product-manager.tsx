"use client"

import { useState } from "react"
import useSWR, { mutate } from "swr"
import { Plus, Pencil, Trash2, Save, X, Globe, Server, HardDrive, Wifi } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Product {
  id: string
  title: string
  description: string
  icon: string
  features: string[]
  redirectPath: string
  enabled: boolean
}

const iconOptions = [
  { value: "Globe", label: "Globe", icon: Globe },
  { value: "Server", label: "Server", icon: Server },
  { value: "HardDrive", label: "HardDrive", icon: HardDrive },
  { value: "Wifi", label: "Wifi", icon: Wifi },
]

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function ProductManager() {
  const { data: products, isLoading } = useSWR<Product[]>("/api/products", fetcher)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  const handleAddNew = () => {
    setEditingProduct({
      id: "",
      title: "",
      description: "",
      icon: "Globe",
      features: [""],
      redirectPath: "",
      enabled: true,
    })
    setIsDialogOpen(true)
  }

  const handleEdit = (product: Product) => {
    setEditingProduct({ ...product })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Weet je zeker dat je dit product wilt verwijderen?")) return

    await fetch(`/api/products/${id}`, { method: "DELETE" })
    mutate("/api/products")
  }

  const handleSave = async () => {
    if (!editingProduct) return
    setIsSaving(true)

    const method = editingProduct.id ? "PUT" : "POST"
    const url = editingProduct.id ? `/api/products/${editingProduct.id}` : "/api/products"

    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editingProduct),
    })

    mutate("/api/products")
    setIsDialogOpen(false)
    setEditingProduct(null)
    setIsSaving(false)
  }

  const handleToggleEnabled = async (product: Product) => {
    await fetch(`/api/products/${product.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...product, enabled: !product.enabled }),
    })
    mutate("/api/products")
  }

  const updateFeature = (index: number, value: string) => {
    if (!editingProduct) return
    const newFeatures = [...editingProduct.features]
    newFeatures[index] = value
    setEditingProduct({ ...editingProduct, features: newFeatures })
  }

  const addFeature = () => {
    if (!editingProduct) return
    setEditingProduct({ ...editingProduct, features: [...editingProduct.features, ""] })
  }

  const removeFeature = (index: number) => {
    if (!editingProduct) return
    const newFeatures = editingProduct.features.filter((_, i) => i !== index)
    setEditingProduct({ ...editingProduct, features: newFeatures })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Producten</h2>
          <p className="text-sm text-muted-foreground">Beheer je producten en redirect-paden</p>
        </div>
        <Button onClick={handleAddNew} className="gap-2">
          <Plus className="h-4 w-4" />
          Nieuw product
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {products?.map((product) => {
          const IconComponent = iconOptions.find(i => i.value === product.icon)?.icon || Globe
          return (
            <Card key={product.id} className={`border-border bg-card ${!product.enabled ? "opacity-60" : ""}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div>
                      <CardTitle className="text-base text-foreground">{product.title}</CardTitle>
                      <CardDescription className="text-xs">/{product.redirectPath}</CardDescription>
                    </div>
                  </div>
                  <Switch
                    checked={product.enabled}
                    onCheckedChange={() => handleToggleEnabled(product)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(product)} className="flex-1 gap-1">
                    <Pencil className="h-3 w-3" />
                    Bewerken
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(product.id)} className="text-destructive hover:bg-destructive/10">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingProduct?.id ? "Product bewerken" : "Nieuw product"}</DialogTitle>
            <DialogDescription>
              Vul de productgegevens in. Het redirect-pad bepaalt waar gebruikers naartoe gaan bij bestellen.
            </DialogDescription>
          </DialogHeader>

          {editingProduct && (
            <FieldGroup>
              <Field>
                <FieldLabel>Titel</FieldLabel>
                <Input
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  placeholder="Webhosting"
                />
              </Field>

              <Field>
                <FieldLabel>Beschrijving</FieldLabel>
                <Textarea
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  placeholder="Korte beschrijving van het product"
                  rows={2}
                />
              </Field>

              <Field>
                <FieldLabel>Icoon</FieldLabel>
                <Select
                  value={editingProduct.icon}
                  onValueChange={(value) => setEditingProduct({ ...editingProduct, icon: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {iconOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center gap-2">
                          <option.icon className="h-4 w-4" />
                          {option.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field>
                <FieldLabel>Redirect-pad</FieldLabel>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">klanten.pw-services.nl/</span>
                  <Input
                    value={editingProduct.redirectPath}
                    onChange={(e) => setEditingProduct({ ...editingProduct, redirectPath: e.target.value })}
                    placeholder="webhosting"
                    className="flex-1"
                  />
                </div>
              </Field>

              <Field>
                <FieldLabel>Kenmerken</FieldLabel>
                <div className="space-y-2">
                  {editingProduct.features.map((feature, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={feature}
                        onChange={(e) => updateFeature(index, e.target.value)}
                        placeholder="Kenmerk toevoegen"
                      />
                      {editingProduct.features.length > 1 && (
                        <Button variant="outline" size="icon" onClick={() => removeFeature(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button variant="outline" size="sm" onClick={addFeature} className="gap-1">
                    <Plus className="h-3 w-3" />
                    Kenmerk toevoegen
                  </Button>
                </div>
              </Field>
            </FieldGroup>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Annuleren
            </Button>
            <Button onClick={handleSave} disabled={isSaving} className="gap-2">
              <Save className="h-4 w-4" />
              {isSaving ? "Opslaan..." : "Opslaan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
