"use client"

import { useState, useEffect } from "react"
import { Save, ExternalLink, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"

interface Stat {
  value: string
  label: string
}

interface Settings {
  customerPortalUrl: string
  companyEmail: string
  companyPhone: string
  stats: Stat[]
}

export function SettingsManager() {
  const [settings, setSettings] = useState<Settings>({
    customerPortalUrl: "https://klanten.pw-services.nl",
    companyEmail: "info@pw-services.nl",
    companyPhone: "+31 (0) 6 12345678",
    stats: [
      { value: "99.9%", label: "Uptime" },
      { value: "24/7", label: "Support" },
      { value: "100+", label: "Klanten" },
      { value: "NL", label: "Datacenters" },
    ],
  })
  const [isSaving, setIsSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    fetch("/api/settings")
      .then(res => res.json())
      .then(data => setSettings(data))
      .catch(() => {})
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    })
    setIsSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const updateStat = (index: number, field: keyof Stat, value: string) => {
    const newStats = [...settings.stats]
    newStats[index] = { ...newStats[index], [field]: value }
    setSettings({ ...settings, stats: newStats })
  }

  const addStat = () => {
    setSettings({
      ...settings,
      stats: [...settings.stats, { value: "", label: "" }],
    })
  }

  const removeStat = (index: number) => {
    const newStats = settings.stats.filter((_, i) => i !== index)
    setSettings({ ...settings, stats: newStats })
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">Instellingen</h2>
        <p className="text-sm text-muted-foreground">Algemene website-instellingen</p>
      </div>

      <div className="flex flex-col gap-6">
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-foreground">Algemeen</CardTitle>
            <CardDescription>Pas de algemene instellingen aan</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field>
                <FieldLabel>Klantenportaal URL</FieldLabel>
                <div className="flex gap-2">
                  <Input
                    value={settings.customerPortalUrl}
                    onChange={(e) => setSettings({ ...settings, customerPortalUrl: e.target.value })}
                    placeholder="https://klanten.pw-services.nl"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => window.open(settings.customerPortalUrl, "_blank")}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </Field>

              <Field>
                <FieldLabel>E-mailadres</FieldLabel>
                <Input
                  type="email"
                  value={settings.companyEmail}
                  onChange={(e) => setSettings({ ...settings, companyEmail: e.target.value })}
                  placeholder="info@pw-services.nl"
                />
              </Field>

              <Field>
                <FieldLabel>Telefoonnummer</FieldLabel>
                <Input
                  value={settings.companyPhone}
                  onChange={(e) => setSettings({ ...settings, companyPhone: e.target.value })}
                  placeholder="+31 (0) 6 12345678"
                />
              </Field>
            </FieldGroup>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-foreground">Statistieken</CardTitle>
            <CardDescription>De statistieken die op de homepage worden getoond</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              {settings.stats.map((stat, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    value={stat.value}
                    onChange={(e) => updateStat(index, "value", e.target.value)}
                    placeholder="Waarde (bijv. 99.9%)"
                    className="flex-1"
                  />
                  <Input
                    value={stat.label}
                    onChange={(e) => updateStat(index, "label", e.target.value)}
                    placeholder="Label (bijv. Uptime)"
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => removeStat(index)}
                    className="shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              
              <Button variant="outline" onClick={addStat} className="gap-2">
                <Plus className="h-4 w-4" />
                Statistiek toevoegen
              </Button>
            </div>
          </CardContent>
        </Card>

        <Button onClick={handleSave} disabled={isSaving} className="gap-2">
          <Save className="h-4 w-4" />
          {isSaving ? "Opslaan..." : saved ? "Opgeslagen!" : "Instellingen opslaan"}
        </Button>
      </div>
    </div>
  )
}
