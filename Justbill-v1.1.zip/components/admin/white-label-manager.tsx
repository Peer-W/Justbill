"use client"

import { useState } from "react"
import { Eye, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function WhiteLabelManager() {
  const [brand, setBrand] = useState({ name: "JustBill", url: "https://justbill.xyz", primary: "#3b82f6", accent: "#8b5cf6", css: "" })
  const [saved, setSaved] = useState(false)
  const save = () => { setSaved(true); window.setTimeout(() => setSaved(false), 1800) }
  return <div className="max-w-4xl space-y-6"><div><h2 className="text-2xl font-bold">White-label branding</h2><p className="text-sm text-muted-foreground">Make the customer experience match your brand.</p></div><Card><CardHeader><CardTitle>Brand identity</CardTitle><CardDescription>These values are used across the portal and checkout.</CardDescription></CardHeader><CardContent className="grid gap-4 sm:grid-cols-2"><label className="grid gap-2 text-sm">Brand name<Input value={brand.name} onChange={(event) => setBrand({ ...brand, name: event.target.value })} /></label><label className="grid gap-2 text-sm">Official website<Input value={brand.url} onChange={(event) => setBrand({ ...brand, url: event.target.value })} /></label><label className="grid gap-2 text-sm">Primary color<Input type="color" value={brand.primary} onChange={(event) => setBrand({ ...brand, primary: event.target.value })} /></label><label className="grid gap-2 text-sm">Accent color<Input type="color" value={brand.accent} onChange={(event) => setBrand({ ...brand, accent: event.target.value })} /></label></CardContent></Card><Card><CardHeader><CardTitle>Custom CSS</CardTitle><CardDescription>Add optional CSS overrides. Review carefully before publishing.</CardDescription></CardHeader><CardContent className="space-y-4"><Textarea value={brand.css} onChange={(event) => setBrand({ ...brand, css: event.target.value })} className="min-h-48 font-mono text-xs" placeholder=".pricing-card { ... }" /><div className="flex gap-2"><Button variant="outline" onClick={() => window.open("/", "_blank")} className="gap-2"><Eye className="h-4 w-4" />Preview</Button><Button onClick={save} className="gap-2"><Save className="h-4 w-4" />{saved ? "Published" : "Publish changes"}</Button></div></CardContent></Card></div>
}
