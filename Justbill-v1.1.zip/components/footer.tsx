import Image from "next/image"
import Link from "next/link"
import { Mail, MapPin, Phone } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <Image
              src="/logo.png"
              alt="JustBill Logo"
              width={150}
              height={40}
              className="mb-4 h-8 w-auto"
            />
            <p className="mb-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
              JustBill biedt betrouwbare hostingoplossingen voor bedrijven en particulieren. 
              Met onze Nederlandse datacenters garanderen wij snelheid en veiligheid.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-foreground">
              Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="#diensten" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Diensten
                </Link>
              </li>
              <li>
                <Link href="#over-ons" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Over ons
                </Link>
              </li>
              <li>
                <Link href="https://klanten.justbill.xyz" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Klantenportaal
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Privacybeleid
                </Link>
              </li>
              <li>
                <Link href="/voorwaarden" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Algemene Voorwaarden
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-foreground">
              Contact
            </h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <a href="mailto:info@justbill.xyz" className="transition-colors hover:text-foreground">
                  info@justbill.xyz
                </a>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <span>+31 (0) 6 12345678</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                <span>Nederland</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8">
          <p className="text-center text-sm text-muted-foreground">
            &copy; {currentYear} JustBill. Alle rechten voorbehouden.
          </p>
        </div>
      </div>
    </footer>
  )
}
