"use client"

import Image from "next/image"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/logo.png"
            alt="JustBill logo"
            width={180}
            height={50}
            className="h-10 w-auto"
            priority
          />
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          <Link href="#diensten" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Diensten
          </Link>
          <Link href="#over-ons" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Over ons
          </Link>
          <Link
            href="https://justbill.xyz"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="default" size="sm">
              Klantenportaal
            </Button>
          </Link>
        </nav>

        <button
          className="md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6 text-foreground" />
          ) : (
            <Menu className="h-6 w-6 text-foreground" />
          )}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="border-t border-border bg-background px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-4">
            <Link
              href="#diensten"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setMobileMenuOpen(false)}
            >
              Diensten
            </Link>
            <Link
              href="#over-ons"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setMobileMenuOpen(false)}
            >
              Over ons
            </Link>
            <Link
              href="https://justbill.xyz"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="default" size="sm" className="w-full">
                Klantenportaal
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
