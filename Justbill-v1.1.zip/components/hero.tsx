"use client"

import { Server, Shield, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then(res => res.json())

interface Stat {
  value: string
  label: string
}

interface Settings {
  stats: Stat[]
}

export function Hero() {
  const { data: settings } = useSWR<Settings>("/api/settings", fetcher)
  
  const stats = settings?.stats || [
    { value: "99.9%", label: "Uptime" },
    { value: "24/7", label: "Support" },
    { value: "100+", label: "Klanten" },
    { value: "NL", label: "Datacenters" },
  ]

  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 pt-20">
      {/* Background grid effect */}
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
      
      {/* Gradient orbs */}
      <div className="pointer-events-none absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
      <div className="pointer-events-none absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-secondary/20 blur-3xl" />

      <div className="relative z-10 mx-auto max-w-5xl text-center">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-muted/50 px-4 py-2 text-sm text-muted-foreground">
          <Shield className="h-4 w-4 text-primary" />
          <span>99.9% Uptime Garantie</span>
        </div>

        <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl">
          Betrouwbare hosting
          <span className="block bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            voor iedereen
          </span>
        </h1>

        <p className="mx-auto mb-10 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground sm:text-xl">
          Professionele webhosting, krachtige VPS-servers, domeinregistratie en DNS-beheer. 
          Alles wat je nodig hebt om online te groeien.
        </p>

        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link href="#diensten">
            <Button size="lg" className="gap-2 text-base">
              <Zap className="h-5 w-5" />
              Bekijk diensten
            </Button>
          </Link>
          <Link href="https://justbill.xyz" target="_blank" rel="noopener noreferrer">
            <Button size="lg" variant="outline" className="gap-2 text-base">
              <Server className="h-5 w-5" />
              Klantenportaal
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 gap-8 sm:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl font-bold text-primary sm:text-3xl">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
