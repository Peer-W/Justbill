import { ExternalLink, FileJson, Lock, Monitor, Settings, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function InfoSection() {
  return (
    <section id="over-ons" className="relative border-t border-border bg-muted/30 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Hoe werkt JustBill?
          </h2>
          <p className="mx-auto max-w-2xl text-pretty text-lg text-muted-foreground">
            Wij werken met een gescheiden platform voor optimale overzichtelijkheid en veiligheid.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Monitor className="h-6 w-6" />
              </div>
              <CardTitle className="flex items-center gap-2 text-foreground">
                justbill.xyz
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </CardTitle>
              <CardDescription className="text-muted-foreground">Informatie &amp; Presentatie</CardDescription>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p>
                Deze website bevat alle informatie over onze diensten, prijzen en mogelijkheden. 
                Hier kun je ontdekken wat JustBill voor jou kan betekenen.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10 text-secondary">
                <Users className="h-6 w-6" />
              </div>
              <CardTitle className="flex items-center gap-2 text-foreground">
                klanten.justbill.xyz
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </CardTitle>
              <CardDescription className="text-muted-foreground">Klantenportaal</CardDescription>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p>
                Het klantenportaal is de plek voor bestellingen, facturen en support. 
                Beheer al je diensten vanuit één overzichtelijk dashboard.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Settings className="h-6 w-6" />
              </div>
              <CardTitle className="flex items-center gap-2 text-foreground">
                justbill.xyz/admin
                <Lock className="h-4 w-4 text-muted-foreground" />
              </CardTitle>
              <CardDescription className="text-muted-foreground">Beheerderportaal</CardDescription>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p>
                Beheerders kunnen via het adminpaneel producten toevoegen, redirect-paden instellen 
                en alle instellingen beheren.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 rounded-xl border border-border bg-card p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <FileJson className="h-5 w-5" />
            </div>
            <div>
              <h3 className="mb-2 font-semibold text-foreground">JSON-gebaseerde opslag</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Alle producten en instellingen worden opgeslagen in JSON-bestanden. 
                Dit zorgt voor eenvoudig beheer en snelle laadtijden. 
                De standaard admin login is <code className="rounded bg-muted px-1.5 py-0.5 text-xs text-foreground">admin</code> / <code className="rounded bg-muted px-1.5 py-0.5 text-xs text-foreground">admin</code>, 
                maar kan worden aangepast via het admin management.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
