"use client"

import { Globe, HardDrive, Server, Wifi } from "lucide-react"
import { ProductCard } from "@/components/product-card"
import useSWR from "swr"

interface Product {
  id: string
  title: string
  description: string
  icon: string
  features: string[]
  redirectPath: string
  enabled: boolean
}

const iconMap: { [key: string]: typeof Globe } = {
  Globe,
  HardDrive,
  Server,
  Wifi,
}

const defaultProducts: Product[] = [
  {
    id: "webhosting",
    title: "Webhosting",
    description: "Betrouwbare en snelle webhosting voor al je websites.",
    icon: "Globe",
    features: ["Onbeperkte bandbreedte", "SSD-opslag", "Gratis SSL-certificaat", "Dagelijkse backups"],
    redirectPath: "webhosting",
    enabled: true,
  },
  {
    id: "vps",
    title: "VPS-diensten",
    description: "Krachtige virtuele private servers met volledige controle.",
    icon: "Server",
    features: ["Root-toegang", "Keuze uit Linux/Windows", "SSD NVMe-opslag", "Schaalbare resources"],
    redirectPath: "vps",
    enabled: true,
  },
  {
    id: "domeinen",
    title: "Domeinregistratie",
    description: "Registreer je perfecte domeinnaam vandaag nog.",
    icon: "HardDrive",
    features: ["100+ extensies beschikbaar", "Gratis DNS-beheer", "Domein privacy", "Eenvoudig verlengen"],
    redirectPath: "domeinen",
    enabled: true,
  },
  {
    id: "dns",
    title: "PW-DNS",
    description: "Professioneel DNS-beheer voor optimale prestaties.",
    icon: "Wifi",
    features: ["Anycast DNS", "DDoS-bescherming", "Snelle propagatie", "API-toegang"],
    redirectPath: "dns",
    enabled: true,
  },
]

const fetcher = (url: string) => fetch(url).then(res => res.json())

export function Services() {
  const { data: products } = useSWR<Product[]>("/api/products", fetcher, {
    fallbackData: defaultProducts,
  })

  const enabledProducts = products?.filter(p => p.enabled) || defaultProducts

  return (
    <section id="diensten" className="relative py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Onze Diensten
          </h2>
          <p className="mx-auto max-w-2xl text-pretty text-lg text-muted-foreground">
            Van webhosting tot DNS-beheer, wij bieden alles wat je nodig hebt voor een succesvolle online aanwezigheid.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {enabledProducts.map((product) => (
            <ProductCard
              key={product.id}
              title={product.title}
              description={product.description}
              icon={iconMap[product.icon] || Globe}
              features={product.features}
              redirectPath={product.redirectPath}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
